<?php
if (isset($_POST['hapus'])) {
    $komentarid = $_POST['komentarid'];
    $query = mysqli_query($koneksi, "SELECT * FROM komentarfoto WHERE komentarid='$komentarid'");
    $data = mysqli_fetch_array($query);
    if (is_file('../assets/img/' . $data['lokasifile'])) {
        unlink('../assets/img/' . $data['lokasifile']);
    }
    $sql = mysqli_query($koneksi, "DELETE FROM komentarfoto WHERE komentarid='$komentarid'");
    echo "<script>
        alert('komen berhasil dihapus!');
        location.href='../admin/home.php';
        </script>";
}